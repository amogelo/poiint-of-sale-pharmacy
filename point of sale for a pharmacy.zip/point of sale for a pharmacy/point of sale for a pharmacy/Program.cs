﻿using System;
using System.Collections.Generic;

// Product class represents a product in the pharmacy
class Product
{
    public string Name { get; set; }
    public double Price { get; set; }
    public int Quantity { get; set; }

    public Product(string name, double price, int quantity)
    {
        Name = name;
        Price = price;
        Quantity = quantity;
    }
}

// PharmacyPOS class manages the point of sale operations
class PharmacyPOS
{
    private List<Product> products;

    public PharmacyPOS()
    {
        // Initialize some sample products
        products = new List<Product>
        {
            new Product("Paracetamol", 2.5, 100),
            new Product("Aspirin", 1.75, 150),
            new Product("Antacid", 3.0, 120),
            new Product("Bandages", 1.0, 200)
        };
    }

    public void DisplayMenu()
    {
        Console.WriteLine("Available Products:");
        for (int i = 0; i < products.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {products[i].Name} - R{products[i].Price} (Qty: {products[i].Quantity})");
        }
        Console.WriteLine();
    }

    public void ProcessSale()
    {
        Console.WriteLine("Enter the number of the product to purchase (or 0 to finish):");
        int productNumber;
        double total = 0;
        do
        {
            DisplayMenu();
            if (!int.TryParse(Console.ReadLine(), out productNumber) || productNumber < 0 || productNumber > products.Count)
            {
                Console.WriteLine("Invalid input. Please enter a valid product number.");
                continue;
            }
            if (productNumber == 0)
            {
                break;
            }
            Product selectedProduct = products[productNumber - 1];
            if (selectedProduct.Quantity == 0)
            {
                Console.WriteLine("Sorry, this product is out of stock.");
                continue;
            }
            total += selectedProduct.Price;
            selectedProduct.Quantity--;
            Console.WriteLine($"Added {selectedProduct.Name} to the cart. Current total: ${total}");
        } while (productNumber != 0);

        Console.WriteLine($"Total: R{total}. Thank you for shopping with us!");
    }
}

// Main method to start the pharmacy POS system
class Program
{
    static void Main()
    {
        PharmacyPOS pos = new PharmacyPOS();
        pos.ProcessSale();
    }
}

